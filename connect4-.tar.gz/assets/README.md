# CONNECT4: Neural Arena

**AstraMind Studios Presents**

A complete, professional-grade AI-based Connect 4 game built entirely using Python and Pygame. This project strongly focuses on Artificial Intelligence algorithms and serves as an impressive university AI mini-project demonstration.

## Features

- **Cinematic Intro & Professional UI**: High-end futuristic neon theme, smooth animations, glowing text, and particle effects.
- **Multiple Game Modes**: 
  - Human vs AI
  - AI vs AI
  - Human vs Human
- **Advanced AI Algorithms**:
  - Minimax Algorithm
  - Alpha-Beta Pruning
  - Custom Heuristic Evaluation (center column preference, window scoring)
  - Move Ordering for Optimized Pruning
- **Difficulty Levels**:
  - Easy: Randomized / Shallow Search (Depth 1)
  - Medium: Minimax (Depth 3)
  - Hard: Alpha-Beta Pruning (Depth 5)
  - Expert: Optimized Alpha-Beta with Move Ordering (Depth 6)
  - Impossible: Deep Optimized Alpha-Beta (Depth 7)
- **AI Visualization Panel**: Real-time telemetry displaying active algorithm, search depth, nodes explored, branches pruned, evaluation time, and best move score.

## Installation

1. Ensure you have Python 3.8+ installed.
2. Clone this repository.
3. Install the required dependencies:

```bash
pip install -r requirements.txt
```

## Running the Game

Launch the game by executing the `main.py` file:

```bash
python main.py
```

## Architecture

- `main.py`: Application entry point and state machine (Intro, Menu, Game).
- `states.py`: Manages the specific states of the application, rendering UI, handling transitions, and running AI threads to avoid UI freezing.
- `ui.py`: Custom Pygame UI components (Buttons, Neon Text, Particle Systems, AI Panel).
- `board.py`: Numpy-based efficient Connect 4 logic and move evaluation logic.
- `ai.py`: Implements the Minimax and Alpha-Beta algorithms with pruning and advanced heuristic scoring.
- `config.py`: Centralized configuration for styling, dimensions, and game rules.